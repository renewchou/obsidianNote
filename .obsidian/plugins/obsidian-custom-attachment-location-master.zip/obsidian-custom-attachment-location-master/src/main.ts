import './styles/main.scss';
import { Plugin } from './Plugin.ts';

// eslint-disable-next-line import-x/no-default-export -- Obsidian infrastructure requires a default export.
export default Plugin;
